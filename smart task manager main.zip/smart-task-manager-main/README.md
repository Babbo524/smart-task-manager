# smart-task-manager
A universal interactive task manager with group support and ADHD tools
